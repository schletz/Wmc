<h1>Home</h1>
<?php
echo $viewData['message']
?>