<h1>Produktliste</h1>
<?php
echo $viewData
?>

