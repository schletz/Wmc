<h1>Stores</h1>
<?php
echo $viewData['message']
?>
